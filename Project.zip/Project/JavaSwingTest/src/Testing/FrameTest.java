package Testing;
import javax.swing.*;
import java.awt.*;


public class FrameTest {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(400,500);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.getContentPane().setBackground(new Color(255,255,255));
		frame.setResizable(false);
		frame.setTitle("CAmoda Shoping");
		
		ImageIcon logo = new ImageIcon("logo2.png2.png");
		 Image image = logo.getImage();
	     Image newImage = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH); // Novo tamanho 150x150
	     logo = new ImageIcon(newImage);
		
		
		JLabel label = new JLabel(logo);
        label.setBounds(20, 1, logo.getIconWidth(), logo.getIconHeight()); // Ajuste conforme necessário
		label.setVisible(true);
		label.setOpaque(false);
		
		
		
		JButton registerBtn = new JButton();
		registerBtn.setBounds(110,250,170,40);
		//registerBtn.addActionListener(e -> System.out.println("heello"));
		registerBtn.setBackground(new Color(44,148,232));
		registerBtn.setText("Register");
		registerBtn.setFont(new Font("Arial", Font.BOLD, 20));
		registerBtn.setFocusable(false);
		registerBtn.setForeground(new Color(0xFFFFFFFF));
		registerBtn.setBorder(BorderFactory.createLineBorder(Color.black, 3));
		
		JButton loginBtn = new JButton();
		loginBtn.setBounds(110,300,170,40);
		//loginBtn.addActionListener(e -> System.out.println("heello"));
		loginBtn.setBackground(new Color(255,255,255));
		loginBtn.setText("Login");
		loginBtn.setFont(new Font("Arial", Font.BOLD, 20));
		loginBtn.setFocusable(false);
		loginBtn.setForeground(new Color(0,0,0));
		loginBtn.setBorder(BorderFactory.createLineBorder(Color.black, 3));

		
		frame.add(registerBtn);
		frame.add(loginBtn);
		frame.add(label);
		frame.setVisible(true);
		
	}
}
